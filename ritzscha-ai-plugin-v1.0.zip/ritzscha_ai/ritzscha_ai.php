<?php

/**
 * RitzSCHA AI Assistant
 *
 * Adds an AI writing assistant to Roundcube's compose window and a
 * one-click summary to the message view.
 *
 * THE KEY POINT, AND THE REASON THIS PLUGIN EXISTS:
 * every user brings their OWN provider API key. The key is held in that
 * person's browser (localStorage, scoped to the webmail origin). It is
 * sent with each request, used once to call the provider, and discarded.
 *
 * It is never written to the database, the session, a cookie, a
 * configuration file, or a log. A compromise of this server does not
 * yield anybody's API key, because there is no store to read.
 *
 * The server acts only as a proxy, and it has to: none of the providers
 * reliably permit direct browser calls (CORS), so the request cannot be
 * made from the page itself.
 *
 * @author  Chandrahas Technologies Private Limited
 * @licence GPL-3.0+
 */
class ritzscha_ai extends rcube_plugin
{
    public $task = 'mail|settings';

    /** @var rcmail */
    private $rc;

    /**
     * Provider table.
     *
     * Endpoints and auth shapes were verified against each provider's own
     * documentation in September 2026. Model IDs are DELIBERATELY not
     * hardcoded here — every one of these vendors renamed or retired a
     * model family during 2026, and a hardcoded list is a plugin that
     * breaks silently a month later. The user types the model name; the
     * settings page offers a current suggestion and says to check it.
     */
    private static $providers = [
        'openai' => [
            'label'    => 'OpenAI',
            'url'      => 'https://api.openai.com/v1/chat/completions',
            'shape'    => 'openai',
            'auth'     => 'bearer',
            'keys_url' => 'https://platform.openai.com/api-keys',
        ],
        'anthropic' => [
            'label'    => 'Anthropic (Claude)',
            'url'      => 'https://api.anthropic.com/v1/messages',
            'shape'    => 'anthropic',
            'auth'     => 'x-api-key',
            'keys_url' => 'https://console.anthropic.com/settings/keys',
        ],
        'gemini' => [
            'label'    => 'Google Gemini',
            'url'      => 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
            'shape'    => 'openai',
            'auth'     => 'bearer',
            'keys_url' => 'https://aistudio.google.com/apikey',
        ],
        'mistral' => [
            'label'    => 'Mistral',
            'url'      => 'https://api.mistral.ai/v1/chat/completions',
            'shape'    => 'openai',
            'auth'     => 'bearer',
            'keys_url' => 'https://console.mistral.ai/api-keys',
        ],
        'deepseek' => [
            'label'    => 'DeepSeek',
            'url'      => 'https://api.deepseek.com/chat/completions',
            'shape'    => 'openai',
            'auth'     => 'bearer',
            'keys_url' => 'https://platform.deepseek.com/api_keys',
        ],
        'groq' => [
            'label'    => 'Groq',
            'url'      => 'https://api.groq.com/openai/v1/chat/completions',
            'shape'    => 'openai',
            'auth'     => 'bearer',
            'keys_url' => 'https://console.groq.com/keys',
        ],
        'openrouter' => [
            'label'    => 'OpenRouter',
            'url'      => 'https://openrouter.ai/api/v1/chat/completions',
            'shape'    => 'openai',
            'auth'     => 'bearer',
            'keys_url' => 'https://openrouter.ai/keys',
        ],
        'xai' => [
            'label'    => 'xAI (Grok)',
            'url'      => 'https://api.x.ai/v1/chat/completions',
            'shape'    => 'openai',
            'auth'     => 'bearer',
            'keys_url' => 'https://console.x.ai',
        ],
    ];

    public function init()
    {
        $this->rc = rcmail::get_instance();
        $this->load_config();
        $this->add_texts('localization/', true);

        if ($this->rc->task == 'settings') {
            $this->add_hook('settings_actions', [$this, 'settings_actions']);
            $this->register_action('plugin.ritzscha_ai', [$this, 'settings_page']);
        }

        if ($this->rc->task == 'mail') {
            $this->include_script('ritzscha_ai.js');
            $this->include_stylesheet($this->local_skin_path() . '/ritzscha_ai.css');

            $this->rc->output->set_env('ritzscha_ai_providers', $this->provider_list_for_js());

            if ($this->rc->action == 'compose') {
                $this->add_button([
                    'command'    => 'plugin.ritzscha_ai.compose',
                    'type'       => 'link',
                    'class'      => 'button ritzscha-ai',
                    'classact'   => 'button ritzscha-ai',
                    'innerclass' => 'inner',
                    'title'      => 'ritzscha_ai.assistant',
                    'label'      => 'ritzscha_ai.ailabel',
                ], 'toolbar');
            }
            elseif ($this->rc->action == 'show' || $this->rc->action == 'preview') {
                $this->add_button([
                    'command'    => 'plugin.ritzscha_ai.summarise',
                    'type'       => 'link',
                    'class'      => 'button ritzscha-ai-sum',
                    'classact'   => 'button ritzscha-ai-sum',
                    'innerclass' => 'inner',
                    'title'      => 'ritzscha_ai.summarise',
                    'label'      => 'ritzscha_ai.summarise',
                ], 'toolbar');
            }
        }

        // The proxy call. Registered for both tasks so the settings page can
        // run its own connection test.
        $this->register_action('plugin.ritzscha_ai.chat', [$this, 'chat']);
    }

    public function settings_actions($args)
    {
        $args['actions'][] = [
            'action' => 'plugin.ritzscha_ai',
            'class'  => 'ritzscha-ai',
            'label'  => 'settingstitle',
            'domain' => 'ritzscha_ai',
            'title'  => 'settingstitle',
        ];

        return $args;
    }

    public function settings_page()
    {
        $this->include_script('ritzscha_ai.js');
        $this->include_stylesheet($this->local_skin_path() . '/ritzscha_ai.css');

        $this->rc->output->set_env('ritzscha_ai_providers', $this->provider_list_for_js());
        $this->register_handler('plugin.body', [$this, 'settings_form']);
        $this->rc->output->set_pagetitle($this->gettext('settingstitle'));
        $this->rc->output->send('plugin');
    }

    public function settings_form()
    {
        $opts = [];
        foreach (self::$providers as $id => $p) {
            $opts[$id] = $p['label'];
        }

        $select = new html_select(['name' => 'provider', 'id' => 'ritzscha-ai-provider', 'class' => 'form-control custom-select']);
        $select->add(array_values($opts), array_keys($opts));

        $table = new html_table(['cols' => 2, 'class' => 'propform']);

        $table->add('title', html::label('ritzscha-ai-provider', rcube::Q($this->gettext('provider'))));
        $table->add('', $select->show(''));

        $table->add('title', html::label('ritzscha-ai-model', rcube::Q($this->gettext('model'))));
        $table->add('', html::tag('input', [
            'type' => 'text', 'id' => 'ritzscha-ai-model', 'name' => 'model',
            'class' => 'form-control', 'autocomplete' => 'off', 'spellcheck' => 'false',
        ]) . html::div(['class' => 'ritzscha-ai-hint'], rcube::Q($this->gettext('modelhint'))));

        $table->add('title', html::label('ritzscha-ai-key', rcube::Q($this->gettext('apikey'))));
        $table->add('', html::tag('input', [
            'type' => 'password', 'id' => 'ritzscha-ai-key', 'name' => 'apikey',
            'class' => 'form-control', 'autocomplete' => 'off', 'spellcheck' => 'false',
        ]) . html::div(['class' => 'ritzscha-ai-hint', 'id' => 'ritzscha-ai-keylink'], ''));

        $buttons = html::p(['class' => 'formbuttons'],
            html::tag('button', ['type' => 'button', 'id' => 'ritzscha-ai-save', 'class' => 'btn btn-primary'], rcube::Q($this->gettext('save')))
            . ' '
            . html::tag('button', ['type' => 'button', 'id' => 'ritzscha-ai-test', 'class' => 'btn btn-secondary ritzscha-ai-btn'], rcube::Q($this->gettext('testconnection')))
            . ' '
            . html::tag('button', ['type' => 'button', 'id' => 'ritzscha-ai-forget', 'class' => 'btn btn-secondary ritzscha-ai-btn'], rcube::Q($this->gettext('forgetkey')))
        );

        $notice = html::div(['class' => 'ritzscha-ai-notice'],
            html::span(['class' => 'ritzscha-ai-notice-title'], rcube::Q($this->gettext('privacytitle')))
            . html::p([], rcube::Q($this->gettext('privacybody')))
        );

        $out = html::div(['class' => 'box formcontainer scroller'],
            html::div(['class' => 'boxtitle'], rcube::Q($this->gettext('settingstitle')))
            . html::div(['class' => 'boxcontent'],
                $notice
                . $table->show()
                . $buttons
                . html::div(['id' => 'ritzscha-ai-status', 'class' => 'ritzscha-ai-status'], '')
            )
        );

        return $out;
    }

    /**
     * The proxy. Takes the user's key, uses it once, returns the text.
     * Nothing is stored and nothing is logged.
     */
    public function chat()
    {
        $provider = rcube_utils::get_input_value('_provider', rcube_utils::INPUT_POST);
        $model    = trim((string) rcube_utils::get_input_value('_model', rcube_utils::INPUT_POST));
        $key      = trim((string) rcube_utils::get_input_value('_key', rcube_utils::INPUT_POST));
        $system   = (string) rcube_utils::get_input_value('_system', rcube_utils::INPUT_POST);
        $prompt   = (string) rcube_utils::get_input_value('_prompt', rcube_utils::INPUT_POST);

        $max_chars = (int) $this->rc->config->get('ritzscha_ai_max_chars', 24000);
        $timeout   = (int) $this->rc->config->get('ritzscha_ai_timeout', 60);
        $allowed   = (array) $this->rc->config->get('ritzscha_ai_providers', array_keys(self::$providers));

        if (!isset(self::$providers[$provider]) || !in_array($provider, $allowed, true)) {
            return $this->fail($this->gettext('errprovider'));
        }
        if ($model === '') {
            return $this->fail($this->gettext('errnomodel'));
        }
        if ($key === '') {
            return $this->fail($this->gettext('errnokey'));
        }
        if ($prompt === '') {
            return $this->fail($this->gettext('errnoprompt'));
        }
        if (strlen($prompt) > $max_chars) {
            $prompt = substr($prompt, 0, $max_chars);
        }

        $p = self::$providers[$provider];

        if ($p['shape'] === 'anthropic') {
            $headers = [
                'x-api-key'         => $key,
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ];
            $body = [
                'model'      => $model,
                'max_tokens' => 2048,
                'messages'   => [['role' => 'user', 'content' => $prompt]],
            ];
            if ($system !== '') {
                $body['system'] = $system;
            }
        }
        else {
            $headers = [
                'Authorization' => 'Bearer ' . $key,
                'content-type'  => 'application/json',
            ];
            $messages = [];
            if ($system !== '') {
                $messages[] = ['role' => 'system', 'content' => $system];
            }
            $messages[] = ['role' => 'user', 'content' => $prompt];
            // No token limit is sent on purpose. OpenAI's reasoning models
            // reject max_tokens and want max_completion_tokens; several
            // OpenAI-compatible providers do not know the latter. The field
            // is optional everywhere, so the safe move is to omit it.
            $body = ['model' => $model, 'messages' => $messages];
        }

        try {
            $client = $this->rc->get_http_client(['timeout' => $timeout]);
            $res    = $client->request('POST', $p['url'], [
                'headers'     => $headers,
                'json'        => $body,
                'http_errors' => false,
            ]);

            $status = $res->getStatusCode();
            $raw    = (string) $res->getBody();
            $json   = json_decode($raw, true);

            if ($status < 200 || $status >= 300) {
                return $this->fail($this->provider_error($status, $json));
            }

            $text = $this->extract_text($p['shape'], $json);

            if ($text === null || $text === '') {
                return $this->fail($this->gettext('errempty'));
            }

            $this->rc->output->command('plugin.ritzscha_ai_result', ['text' => $text]);
            $this->rc->output->send();
        }
        catch (Exception $e) {
            // The exception message is NOT passed through: a Guzzle
            // exception can echo the request, and the request carries the
            // key. Only a generic message reaches the browser or the log.
            rcube::write_log('errors', 'ritzscha_ai: request failed (' . get_class($e) . ')');
            return $this->fail($this->gettext('errnetwork'));
        }
    }

    private function extract_text($shape, $json)
    {
        if (!is_array($json)) {
            return null;
        }

        if ($shape === 'anthropic') {
            if (!empty($json['content']) && is_array($json['content'])) {
                $parts = [];
                foreach ($json['content'] as $block) {
                    if (isset($block['type'], $block['text']) && $block['type'] === 'text') {
                        $parts[] = $block['text'];
                    }
                }
                return $parts ? implode("\n", $parts) : null;
            }
            return null;
        }

        return $json['choices'][0]['message']['content'] ?? null;
    }

    private function provider_error($status, $json)
    {
        $msg = $json['error']['message'] ?? ($json['message'] ?? '');

        if ($status == 401 || $status == 403) {
            return $this->gettext('errauth');
        }
        if ($status == 404) {
            return $this->gettext('errmodel');
        }
        if ($status == 429) {
            return $this->gettext('errrate');
        }

        $out = $this->gettext('errprovidersaid') . ' (' . $status . ')';
        if ($msg) {
            $out .= ': ' . mb_substr($msg, 0, 300);
        }

        return $out;
    }

    private function fail($message)
    {
        $this->rc->output->command('plugin.ritzscha_ai_error', ['message' => $message]);
        $this->rc->output->send();
    }

    private function provider_list_for_js()
    {
        $allowed = (array) $this->rc->config->get('ritzscha_ai_providers', array_keys(self::$providers));
        $out     = [];

        foreach (self::$providers as $id => $p) {
            if (!in_array($id, $allowed, true)) {
                continue;
            }
            $out[$id] = [
                'label'    => $p['label'],
                'keys_url' => $p['keys_url'],
            ];
        }

        return $out;
    }
}
