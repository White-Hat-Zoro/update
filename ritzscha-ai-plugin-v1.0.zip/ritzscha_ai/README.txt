RitzSCHA AI Assistant — Roundcube plugin
Chandrahas Technologies Private Limited
Version 1.0 — 5 September 2026
Built and tested against Roundcube 1.6.11


WHAT IT DOES
------------
Compose window   an "AI" button opens an assistant: Draft an email, Draft a
                 reply, Improve writing, Make shorter, Expand notes, More
                 formal, More friendly, Fix grammar — plus a free-text
                 instruction box. The result appears in the dialog and goes
                 nowhere near your message until you press Insert or Replace.

Message view     a "Summarise" button gives up to five bullet points and one
                 line saying what you are being asked to do.

Settings         a new "AI Assistant" section where each person chooses their
                 provider, types the model name, and pastes their own key.


THE POINT: EVERY USER BRINGS THEIR OWN KEY
------------------------------------------
There is no company API key anywhere in this plugin. Each person uses their
own account with their own provider, and their own usage is billed to them.

The key is stored ONLY in that person's browser (localStorage, scoped to the
webmail address). It is sent with each request, used once, and discarded.

It is never written to:
  - the Roundcube database
  - the PHP session
  - a cookie
  - any configuration file
  - any log

A compromise of the mail server does not yield anybody's API key, because
there is no store to read. That was the design goal, and it is why the
settings page saves nothing to the server at all.

The one honest caveat: the server acts as a proxy, so the key passes THROUGH
PHP in memory for the duration of one request. It has to — none of the
providers reliably allow a browser to call them directly (CORS), so the
request cannot be made from the page itself. The key is never at rest on the
server, but it is in transit through it. Anyone who could inject code into a
running Roundcube could capture it in flight; the same person could equally
capture the mailbox password, so this does not change the security posture of
the server. It does mean the plugin is only as trustworthy as the server.

Consequence for users: on a new computer or a new browser, the key is entered
again. This is deliberate.


PROVIDERS
---------
OpenAI · Anthropic (Claude) · Google Gemini · Mistral · DeepSeek · Groq ·
OpenRouter · xAI (Grok).

Endpoints and authentication were verified against each provider's own
documentation in September 2026. Two request shapes are implemented: the
OpenAI-compatible shape, which covers seven of the eight, and Anthropic's
native /v1/messages shape, which uses x-api-key and returns content blocks
rather than choices.

MODEL NAMES ARE NOT HARDCODED, AND THAT IS DELIBERATE. Every one of these
vendors renamed or retired a model family during 2026 — Groq alone retired
three in five months. A hardcoded model list is a plugin that breaks silently
a month later. The user types the model name; the settings page says to check
the provider's current list rather than trusting a name from months ago.

To offer fewer providers, copy config.inc.php.dist to config.inc.php in the
plugin folder and shorten the list.


INSTALLING
----------
1. aaPanel -> Files -> /www/wwwroot/mail.chandrahastech.org/plugins
2. Upload this zip, right-click -> Unzip, delete the zip.
   The folder must be named exactly:  ritzscha_ai
3. Edit config/config.inc.php and add 'ritzscha_ai' to $config['plugins'].
   Take a copy of that file first.
4. Reload webmail.

No Composer. No database change. No service restart. Nothing outside the
plugins folder and one word in the config.


TURNING IT OFF
--------------
Remove 'ritzscha_ai' from $config['plugins'] and reload. The folder can stay.
Deleting the folder is also safe. Nothing else to undo — the plugin writes
nothing to the server.


WHAT WAS ACTUALLY TESTED, AND WHAT WAS NOT
------------------------------------------
Tested on a real Roundcube 1.6.11 with a live Dovecot, driven in Chromium:

  - the plugin loads with no PHP error and no JavaScript error
  - the Settings section renders and lists all eight providers
  - the AI button appears in the compose toolbar and opens the dialog
  - the Summarise button appears in the message view and opens its dialog
  - a REAL HTTPS request reaches the provider and comes back
  - a rejected key produces "The provider rejected your API key", not a stack
    trace and not a raw error
  - the response parser was unit-tested against OpenAI-shaped JSON,
    Anthropic-shaped JSON, Anthropic responses containing thinking blocks,
    malformed JSON and null

NOT tested: a successful 200 response from a live provider. That needs a real
funded API key, which was deliberately never requested. The parsing of a
success response was proven separately by unit test, but the first genuine
end-to-end success will happen on your server, with your key. Use "Test
connection" on the settings page first — it makes the smallest possible call
and reports exactly what came back.


A BUG THAT WOULD HAVE SHIPPED
-----------------------------
Roundcube blocks any command on the compose screen that is not listed in
env.compose_commands — it assumes the click means "leave compose" and shows
the unsaved-message warning instead of running the command. The AI button
looked correct, was registered correctly, and did nothing at all. The plugin
now registers its command with compose explicitly. Noted here because anyone
adding another compose button to this Roundcube will hit the same wall.


COSTS AND PRIVACY, FOR WHOEVER USES IT
--------------------------------------
Text sent to the assistant leaves this server and goes to the provider the
user chose, under that user's account. It is billed to them, and it is
subject to that provider's data-retention policy, not ours. Nobody should
paste anything into it that they would not be willing to send to that vendor.

The max_chars setting in config.inc.php.dist caps how much text one request
can carry. It is there so that pasting a very long message cannot quietly run
up somebody's bill.
