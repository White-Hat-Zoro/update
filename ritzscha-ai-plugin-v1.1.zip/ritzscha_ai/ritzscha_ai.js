/**
 * RitzSCHA AI Assistant — browser side.
 *
 * The user's API key lives ONLY in this browser, in localStorage, scoped to
 * the webmail origin. It is read here, sent with the one request that needs
 * it, and never persisted anywhere else. Clearing it here removes it.
 */

window.ritzscha_ai = (function() {

    var STORE = 'ritzscha_ai_settings_v1';

    function load() {
        try {
            var raw = window.localStorage.getItem(STORE);
            return raw ? JSON.parse(raw) : {};
        } catch (e) {
            return {};
        }
    }

    function save(s) {
        try {
            window.localStorage.setItem(STORE, JSON.stringify(s));
            return true;
        } catch (e) {
            return false;
        }
    }

    function forget() {
        try { window.localStorage.removeItem(STORE); } catch (e) {}
    }

    function configured() {
        var s = load();
        return !!(s.provider && s.model && s.key);
    }

    // ---- the one call ----------------------------------------------------

    var pending = null;

    function ask(system, prompt, onDone, onFail) {
        var s = load();

        if (!configured()) {
            onFail(rcmail.get_label('notconfigured', 'ritzscha_ai'));
            return;
        }

        pending = { done: onDone, fail: onFail };

        rcmail.http_post('plugin.ritzscha_ai.chat', {
            _provider: s.provider,
            _model: s.model,
            _key: s.key,
            _system: system || '',
            _prompt: prompt
        }, rcmail.set_busy(true, 'ritzscha_ai.thinking'));
    }

    function handle_result(prop) {
        rcmail.set_busy(false);
        var p = pending; pending = null;
        if (p && p.done) p.done(prop.text || '');
    }

    function handle_error(prop) {
        rcmail.set_busy(false);
        var p = pending; pending = null;
        if (p && p.fail) p.fail(prop.message || 'Error');
    }

    // ---- compose assistant ----------------------------------------------

    var ACTIONS = [
        { id: 'draft',    system: 'You are helping write a business email. Write only the body of the email. Do not add a subject line, and do not explain what you have written.' },
        { id: 'improve',  system: 'Rewrite the text so it reads clearly and professionally. Keep the meaning and the language exactly as they are. Return only the rewritten text.' },
        { id: 'shorten',  system: 'Make the text shorter while keeping every fact and request in it. Return only the shortened text.' },
        { id: 'expand',   system: 'Expand the notes into a complete, polite business email body. Return only the text.' },
        { id: 'formal',   system: 'Rewrite the text in a more formal, professional register. Return only the rewritten text.' },
        { id: 'friendly', system: 'Rewrite the text in a warmer, friendlier tone while staying professional. Return only the rewritten text.' },
        { id: 'grammar',  system: 'Correct spelling, grammar and punctuation. Change nothing else — not the wording, not the tone. Return only the corrected text.' },
        { id: 'reply',    system: 'Write a reply to the email below. Write only the body of the reply. Be concise and businesslike.' }
    ];

    function open_compose_dialog() {
        if (!configured()) {
            settings_prompt();
            return;
        }

        var selected = '';
        try { selected = rcmail.editor.get_content({ selection: true, format: 'text', nosig: true }) || ''; } catch (e) {}
        var whole = '';
        try { whole = rcmail.editor.get_content({ format: 'text', nosig: true }) || ''; } catch (e) {}

        var source = selected || whole;

        var $body = $('<div>').addClass('ritzscha-ai-dialog');

        var $actions = $('<div>').addClass('ritzscha-ai-actions');
        $.each(ACTIONS, function(i, a) {
            $('<button>')
                .attr({ type: 'button', 'data-action': a.id })
                .addClass('btn btn-secondary ritzscha-ai-action')
                .text(rcmail.get_label('act_' + a.id, 'ritzscha_ai'))
                .appendTo($actions);
        });

        var $instr = $('<textarea>')
            .addClass('form-control ritzscha-ai-instruction')
            .attr({ rows: 2, placeholder: rcmail.get_label('instructionhint', 'ritzscha_ai') });

        var $out = $('<textarea>')
            .addClass('form-control ritzscha-ai-output')
            .attr({ rows: 12, readonly: true, placeholder: rcmail.get_label('outputhint', 'ritzscha_ai') });

        var $status = $('<div>').addClass('ritzscha-ai-status');

        $body.append(
            $('<label>').text(rcmail.get_label('whattodo', 'ritzscha_ai')),
            $actions,
            $('<label>').text(rcmail.get_label('instruction', 'ritzscha_ai')),
            $instr,
            $('<label>').text(rcmail.get_label('result', 'ritzscha_ai')),
            $out,
            $status
        );

        // show_popup_dialog, not simple_dialog: simple_dialog builds its own
        // Save/Cancel pair and ignores a buttons array, which is why an
        // earlier version of this rendered nothing at all.
        var buttons = [
            {
                text: rcmail.get_label('insert', 'ritzscha_ai'),
                'class': 'mainaction insert',
                click: function() {
                    var t = $out.val();
                    if (!t) return;
                    rcmail.editor.replace({ text: t });
                    $(this).dialog('close');
                }
            },
            {
                text: rcmail.get_label('replace', 'ritzscha_ai'),
                'class': 'replace',
                click: function() {
                    var t = $out.val();
                    if (!t) return;
                    rcmail.editor.set_content(t.replace(/\r?\n/g, '<br>'));
                    $(this).dialog('close');
                }
            },
            {
                text: rcmail.get_label('close'),
                'class': 'cancel',
                click: function() { $(this).dialog('close'); }
            }
        ];

        rcmail.show_popup_dialog($body, rcmail.get_label('assistant', 'ritzscha_ai'), buttons, { width: 720 });

        $actions.on('click', '.ritzscha-ai-action', function() {
            var id = $(this).data('action'),
                def = null;

            $.each(ACTIONS, function(i, a) { if (a.id == id) def = a; });
            if (!def) return;

            var extra = $.trim($instr.val()),
                text  = $.trim(source);

            if (def.id == 'draft' && !text && !extra) {
                $status.text(rcmail.get_label('needsomething', 'ritzscha_ai'));
                return;
            }

            var prompt = '';
            if (extra) prompt += rcmail.get_label('instruction', 'ritzscha_ai') + ': ' + extra + '\n\n';
            if (text)  prompt += text;
            if (!prompt) prompt = extra;

            $status.text(rcmail.get_label('thinking', 'ritzscha_ai'));
            $out.val('');

            ask(def.system, prompt, function(t) {
                $out.val(t);
                $status.text('');
            }, function(msg) {
                $status.text(msg);
            });
        });
    }

    // ---- summarise a message --------------------------------------------

    function summarise() {
        if (!configured()) {
            settings_prompt();
            return;
        }

        var text = '';
        var $frame = $('#messagecontframe');

        if ($frame.length && $frame[0].contentDocument) {
            text = $($frame[0].contentDocument).find('#messagebody').text();
        }
        if (!text) {
            text = $('#messagebody').text();
        }
        text = $.trim(text);

        if (!text) {
            rcmail.display_message(rcmail.get_label('nomessagetext', 'ritzscha_ai'), 'warning');
            return;
        }

        var $out = $('<textarea>').addClass('form-control ritzscha-ai-output').attr({ rows: 12, readonly: true });
        var $status = $('<div>').addClass('ritzscha-ai-status').text(rcmail.get_label('thinking', 'ritzscha_ai'));
        var $body = $('<div>').addClass('ritzscha-ai-dialog').append($status, $out);

        rcmail.show_popup_dialog($body, rcmail.get_label('summarise', 'ritzscha_ai'), [
            {
                text: rcmail.get_label('close'),
                'class': 'mainaction cancel',
                click: function() { $(this).dialog('close'); }
            }
        ], { width: 680 });

        ask(
            'Summarise the email below for a busy reader. Give at most five short bullet points, then a line beginning "Action:" saying what the reader is being asked to do, or "Action: none" if nothing is asked. Return only that.',
            text,
            function(t) { $out.val(t); $status.text(''); },
            function(msg) { $status.text(msg); }
        );
    }

    function settings_prompt() {
        rcmail.display_message(rcmail.get_label('notconfigured', 'ritzscha_ai'), 'warning');
    }

    // ---- settings page --------------------------------------------------

    function init_settings_page() {
        var $provider = $('#ritzscha-ai-provider'),
            $model    = $('#ritzscha-ai-model'),
            $key      = $('#ritzscha-ai-key'),
            $status   = $('#ritzscha-ai-status'),
            $keylink  = $('#ritzscha-ai-keylink');

        if (!$provider.length) return;

        var s = load();
        if (s.provider) $provider.val(s.provider);
        if (s.model) $model.val(s.model);
        if (s.key) $key.val(s.key);

        function refresh_link() {
            var p = rcmail.env.ritzscha_ai_providers || {},
                cur = p[$provider.val()];
            $keylink.empty();
            if (cur && cur.keys_url) {
                $keylink.append(
                    document.createTextNode(rcmail.get_label('getkeyat', 'ritzscha_ai') + ' '),
                    $('<a>').attr({ href: cur.keys_url, target: '_blank', rel: 'noopener noreferrer' }).text(cur.keys_url)
                );
            }
        }

        $provider.on('change', refresh_link);
        refresh_link();

        $('#ritzscha-ai-save').on('click', function() {
            var next = {
                provider: $provider.val(),
                model: $.trim($model.val()),
                key: $.trim($key.val())
            };
            if (!next.model) { $status.text(rcmail.get_label('errnomodel', 'ritzscha_ai')); return; }
            if (!next.key)   { $status.text(rcmail.get_label('errnokey', 'ritzscha_ai')); return; }

            $status.text(save(next)
                ? rcmail.get_label('savedlocal', 'ritzscha_ai')
                : rcmail.get_label('errstorage', 'ritzscha_ai'));
        });

        $('#ritzscha-ai-forget').on('click', function() {
            forget();
            $model.val(''); $key.val('');
            $status.text(rcmail.get_label('forgotten', 'ritzscha_ai'));
        });

        $('#ritzscha-ai-test').on('click', function() {
            var next = {
                provider: $provider.val(),
                model: $.trim($model.val()),
                key: $.trim($key.val())
            };
            if (!next.model || !next.key) {
                $status.text(rcmail.get_label('errnomodel', 'ritzscha_ai'));
                return;
            }
            save(next);
            $status.text(rcmail.get_label('testing', 'ritzscha_ai'));
            ask('Reply with the single word: ready.', 'Say ready.',
                function(t) { $status.text(rcmail.get_label('testok', 'ritzscha_ai') + ' ' + $.trim(t).substring(0, 60)); },
                function(msg) { $status.text(msg); });
        });
    }

    return {
        open_compose_dialog: open_compose_dialog,
        summarise: summarise,
        handle_result: handle_result,
        handle_error: handle_error,
        init_settings_page: init_settings_page,
        configured: configured
    };
})();

if (window.rcmail) {
    rcmail.addEventListener('init', function() {
        rcmail.addEventListener('plugin.ritzscha_ai_result', window.ritzscha_ai.handle_result);
        rcmail.addEventListener('plugin.ritzscha_ai_error', window.ritzscha_ai.handle_error);

        rcmail.register_command('plugin.ritzscha_ai.compose', window.ritzscha_ai.open_compose_dialog, true);
        rcmail.register_command('plugin.ritzscha_ai.summarise', window.ritzscha_ai.summarise, true);

        // Roundcube blocks any command on the compose screen that is not in
        // env.compose_commands — it assumes the click means "leave compose"
        // and shows the unsaved-message warning instead of running it.
        // Without this line the toolbar button silently does nothing.
        // (app.js, this.command(), the compose guard.)
        if (rcmail.env.compose_commands && $.inArray('plugin.ritzscha_ai.compose', rcmail.env.compose_commands) < 0) {
            rcmail.env.compose_commands.push('plugin.ritzscha_ai.compose');
        }

        window.ritzscha_ai.init_settings_page();
    });
}

/* ==========================================================================
   COMPOSE EDITOR DEFAULTS
   --------------------------------------------------------------------------
   This block is not about AI. It lives here because it needs one JavaScript
   listener on the mail task and this plugin is already loaded on every mail
   page (ritzscha_ai.php line 113). Standing up a second plugin for six lines
   would mean a second thing to install, upgrade and remember. If this ever
   grows, it moves out into its own plugin — that is the line to move.

   Roundcube fires 'editor-init' with the live TinyMCE config object one
   statement BEFORE it calls tinymce.init (program/js/editor.js line 171), so
   changes made here are the configuration the editor actually starts with.
   Nothing in Roundcube's own files is edited, so a Roundcube upgrade cannot
   undo this.

   HONEST LIMIT ON THE FONT SIZE CONTROL. Roundcube 1.6.11 ships TinyMCE
   5.10.9 (program/js/tinymce/tinymce.min.js, majorVersion "5"). In TinyMCE 5
   the size control is 'fontsizeselect', a fixed listbox: it has no text
   entry, so no arbitrary or decimal value can be typed into it whatever the
   configuration says. The editable size spinner ('fontsizeinput') is a
   TinyMCE 6 control and cannot be back-fitted. What CAN be done, and is done
   here, is to give the list every size a business message realistically
   needs, including half-point steps.
   ========================================================================== */

if (window.rcmail) {
    rcmail.addEventListener('editor-init', function(p) {
        if (!p || !p.config) {
            return;
        }

        // Helvetica first, then the rest of Roundcube's own font list
        // (rcmail_action::font_defs). TinyMCE 5 uses 'font_formats'.
        p.config.font_formats =
            'Helvetica=Helvetica,Arial,sans-serif;'
            + 'Arial=Arial,Helvetica,sans-serif;'
            + 'Calibri=Calibri,Candara,Segoe,Optima,sans-serif;'
            + 'Georgia=Georgia,Palatino,serif;'
            + 'Tahoma=Tahoma,Arial,Helvetica,sans-serif;'
            + 'Times New Roman=\'Times New Roman\',Times,serif;'
            + 'Trebuchet MS=\'Trebuchet MS\',Geneva,sans-serif;'
            + 'Verdana=Verdana,Geneva,sans-serif;'
            + 'Courier New=\'Courier New\',Courier,monospace';

        // Roundcube's stock list is 8 9 10 11 12 14 18 24 36pt. Half steps
        // added through the range people actually write body text in.
        p.config.fontsize_formats =
            '8pt 8.5pt 9pt 9.5pt 10pt 10.5pt 11pt 11.5pt 12pt 12.5pt 13pt 14pt '
            + '15pt 16pt 18pt 20pt 22pt 24pt 28pt 32pt 36pt 48pt';
    });
}
