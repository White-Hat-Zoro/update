RitzSCHA Mail — Roundcube skin
Chandrahas Technologies Private Limited
Version 1.0 — 5 September 2026
Compiled and VISUALLY VERIFIED against Roundcube 1.6.11

WHY 0.2 AND NOT 0.1
-------------------
Version 0.1 broke the interface. Its stylesheet began with

    @import url("../../elastic/styles/styles.css");

and that file does not exist. Roundcube ships Elastic's stylesheet only as
styles.min.css. The import failed silently, no base stylesheet loaded at all,
and the webmail rendered as raw HTML.

Version 0.2 does not import anything at run time. It is COMPILED against
Elastic's own LESS sources, so the output is one complete, self-contained
stylesheet with nothing left to resolve in the browser.

Before this file was packaged, a real Roundcube 1.6.11 was installed with a
working IMAP server, this skin was selected, and the login page, inbox,
settings pages, dark mode and a phone-width viewport were each loaded in a
real browser and looked at. Zero failed requests in every case.

For v1.0 that check covered: the login page light and dark, the inbox light
and dark, the compose window light and dark, the editor canvas under a dark
operating system, a dialog over the message list to show the glass, and a
390-pixel phone. Zero requests of 400 or worse, zero JavaScript errors, and
no horizontal scroll at phone width.

WHAT IS IN THE FOLDER
---------------------
  meta.json            "extends": "elastic", the layout, logo and viewport
                       overrides
  styles/styles.css        compiled, readable
  styles/styles.min.css    compiled, minified — this is the one Roundcube uses
  styles/embed.css         the editor canvas — see item 11 below
  styles/embed.min.css
  images/                  the logos and the monogram

No template. Not one. Roundcube resolves every template from Elastic at run
time, so upstream security fixes to Roundcube's markup reach this skin
automatically and for ever. A skin that forks templates freezes today's markup
into itself permanently and invisibly. That is the most important property of
this package.

WHAT IT CHANGES
---------------
1. Colour: company blue in place of Elastic's cyan, and a deep navy task rail.
   Done by redefining Elastic's own LESS colour variables, not by overriding
   class names, so it is consistent everywhere including dark mode.
2. Typography: the device's own system font stack. Nothing is fetched from
   Google; the interface matches the machine it is read on.
3. Removes maximum-scale=1.0 from the viewport. Elastic ships with pinch-zoom
   disabled on phones, which is a WCAG 1.4.4 accessibility failure. Fixed.
4. Restores the layout choice. Elastic 1.6 forces "widescreen" and hides the
   setting; this skin offers all three — widescreen, desktop, list — under
   Settings > Preferences > Mailbox View.
5. STRUCTURE — v0.3. This is the part that makes it stop looking like
   Elastic with a new colour:
   - The message row is now ONE line: sender | subject | date, the way a
     modern mail client draws it. Elastic stacks sender above subject on two
     lines. All three already sit inside a single td as sibling spans, so a
     CSS grid re-flows them without touching the markup.
   - The message list is given the width. Elastic pins three panes at
     248 / 372 / 742 px at EVERY screen size and at every layout setting —
     verified on a live instance — which is why the subject is always
     truncated. The list now takes the room left over; the reading pane is
     fixed at 30rem and is never hidden, so opening a message is untouched.
   - The left column is white with a blue Compose pill, not a dark slab.
   - Unread rows are white and bold; read rows sit back on a soft grey;
     hovering lifts the row instead of just tinting it.
   - Pill search bar, rounded folder rows, rounded buttons and fields,
     slim scrollbars, and wide message content scrolling inside its own box.

6. MODERN CONTROLS — v0.5:
   - The search field is a large grey pill that lightens and lifts on focus,
     the way Gmail's does.
   - Folder rows are fully rounded pills with margin, not full-width bars.
   - Toolbar buttons get circular hover targets instead of square slabs.
   - Buttons are pills. The primary action — Send — is a solid blue pill with
     a shadow; secondary buttons are outlined white.
   - Form fields are taller, rounder, and have a real focus ring.
   - Message rows have rounded ends on hover.
   - The empty reading pane shows a small quiet mark, not a huge watermark.

7. THE COMPOSE PANEL — v0.7. Top to bottom the order is now: address
   fields, the editor filling the card, then Save / Attach / Signature /
   Responses, then Send. Roundcube puts those four buttons in a header ABOVE
   the form and Send INSIDE the form at its end, so CSS cannot move one into
   the other — but it can reorder the flex column (.header to order 2) and
   pin Send to the panel floor with absolute positioning, which puts them in
   the right sequence. The editor stretches to fill instead of leaving a dead
   gap. Elastic pins every toolbar item to exactly 5.25rem, which is what
   clipped "Signature" and "Responses"; that is released here.

8. TWO CORRECTIONS FROM REVIEW — v0.8:
   - Compose in the left rail now has the same shape and size as Mail,
     Contacts and Settings, distinguished by colour and weight rather than by
     a filled blue circle that sat oddly against its neighbours.
   - The "Plain text" toggle — the X at the far left of the formatting bar —
     is hidden. One click on it switched the message to plain text and every
     formatting control vanished, which reads as the editor breaking. Users
     who genuinely want plain text can still set it in
     Settings > Preferences > Composing Messages.
   - v0.9: the "Source code" button (<>) is hidden too. It opens the raw HTML
     of the message. Gmail does not offer it, Outlook does not offer it, and
     on a business mailbox it is a way to break a message rather than write
     one.

   NOTE: hiding the Plain text toggle is only half the fix. Until
   $config['htmleditor'] is set to 1, Roundcube still OPENS compose in plain
   text, and the formatting bar is not there to begin with. The skin cannot
   change that — it is a config line.

   Superseded note from v0.6. Save, Attach, Signature and Responses used to
   float in a separate 58px strip above the form, centred, with their labels
   clipped to "Signatur" and "Response". They are in a different container
   from the form, so CSS cannot reparent them — but the whole thing is now
   drawn as ONE card: the action bar is the card's header with left-aligned
   pill buttons, the form is its body, and Send sits in the card's own bottom
   bar and stays in view as you scroll. Elastic pins every toolbar item to
   exactly 5.25rem, which is what clipped the labels; that is released for
   the compose bar only.

9. THE LOGIN PAGE — v1.0. It had never been touched before this version.
   Elastic positions the logo and the form absolutely with percentage tops,
   which left the form in the upper third with a dead half-screen beneath it.
   Both are now taken out of that flow and laid out as one centred column,
   with a gutter so the card does not run edge to edge on a phone.
   The two icon boxes glued to each field are gone: the icon and the input
   read as one control, with the focus ring on the pair. The Login button is
   a full-width gradient pill.

10. THE LOGOS — v1.0.
   Login page      the wide WeBiii Traume lockup
   Everywhere else the RitzScha triangle monogram, cropped square
   Dark mode       light variants of both, swapped automatically
   Phone           the monogram

   The wordmark under the monogram was dropped for the rail: at 54 pixels it
   is illegible, and an illegible word is worse than no word.

   These are set in config.inc.php, not in the skin — see INSTALLING.

   ONE THING WORTH KNOWING, because it cost an hour. Paths in skin_logo must
   be written WITHOUT a leading slash:

       'ritzscha:*' => 'skins/ritzscha/images/logo-mark.png'    correct
       'ritzscha:*' => '/images/logo-mark.png'                  404s

   The main logo is resolved through the skin chain and works either way, but
   the dark and small variants are resolved by abs_url(), which does not
   search the chain — it prefixes base_path, and while an Elastic template is
   being parsed base_path IS 'skins/elastic'. A leading-slash path therefore
   comes out as skins/elastic/images/..., which does not exist. Measured, not
   guessed: the browser requested exactly that and got a 404.

11. THE EDITOR CANVAS — v1.0, and this is a real defect that was found, not
   a cosmetic choice.

   meta.json points editor_css_location at /styles/embed.css. Roundcube
   builds that path from the CURRENT skin name and looks it up with
   find_asset(), which — unlike get_skin_file() — does NOT walk the skin
   chain. A child skin that does not ship its own embed.css does not inherit
   Elastic's: the lookup fails silently and Roundcube falls back to
   program/resources/tinymce/content.css, the bare default. Every version of
   this skin before 1.0 was composing mail in an unstyled editor and nothing
   said so. Confirmed by reading rcmail.env.editor_config.content_css in the
   browser: it said 'program/resources/tinymce/content.css'.

   The skin now ships styles/embed.css, and the editor is styled again.

   Dark mode inside the editor has one honest limit. Roundcube's own dark
   toggle cannot reach into that frame: Elastic adds the dark-mode class to
   iframes at init, and TinyMCE builds its editing iframe later, so it never
   gets the class — verified, the frame's <html> carried no class at all.
   The canvas therefore follows the OPERATING SYSTEM's dark setting, which is
   how nearly everyone actually arrives at a dark webmail. Background and
   text always move together, so it is never dark-on-dark. Somebody who
   forces dark inside Roundcube on a light Mac keeps a white canvas.

   Closing that last gap needs one line of JavaScript on the editor-init
   event. That belongs in a plugin. It does NOT belong in a forked ui.js,
   which would forfeit every upstream fix to that file.

12. DARK MODE — v1.0. The founder's words were "colours mismatch at many
   location". They did, and here is why.

   Elastic's dark theme is a teal-grey family — background #21292c, borders
   #4d6066 — with an accent of darken(@color-main, 30%), a very dark blue
   used for selected rows and primary buttons ON a dark ground. Against this
   skin's blue panels that read as two different products, and the accent was
   close to unreadable.

   Earlier versions fought this rule by rule with literal colours. v1.0 fixes
   the cause instead: it redefines Elastic's OWN @color-dark-* variables — 27
   of them — to one blue-grey family. LESS evaluates variables lazily, so
   that re-colours every rule inside Elastic's dark.less at once: body,
   panels, borders, inputs, buttons, popovers, scrollbars, the selected row.

   Two things had to be set directly because no variable reaches them:
   - the unread pip, which Elastic hardcodes to darken(@color-warning, 30%)
     — an orange dot in a blue interface. Redefining @color-warning would
     have recoloured genuine warning messages too.
   - the login page's #layout-content, which covers the whole viewport there
     and was painting over the background.

13. GLASS — v1.0. Applied only where something genuinely floats above
   something else: dialogs, popup menus, the search field, the login card.
   Frosting a solid panel that sits on nothing just makes it muddy. The
   login page carries three soft colour pools under the wash, because a flat
   pale ground gives frosted glass nothing to refract and the card then just
   looks like a white box. Where backdrop-filter is unsupported the surface
   degrades to a plain translucent panel, which still looks deliberate.

THE COMPOSE WINDOW — what the skin does and does not control
-------------------------------------------------------------
The rich editor is NOT part of a skin. Roundcube ships TinyMCE and already
has, in its full compose mode: font family, font size (8pt to 36pt), bold,
italic, underline, text colour, highlight colour, four alignments, bulleted
and numbered lists, indent and outdent, left-to-right and right-to-left,
blockquote, insert and edit link, remove link, tables, emoticons, special
characters, images, media, source code, find and replace, undo and redo.
Twenty-nine buttons in total, counted on a live instance.

Two things were hiding them, and this skin fixes the second:

  1. The rich editor is OFF by default. Roundcube's own setting
     $config['htmleditor'] controls it and it ships as 0, meaning "never".
     That is a one-line change in config.inc.php, NOT a skin change.
  2. Even with it on, the toolbar collapsed into a "..." drawer because the
     compose form was too narrow. v0.4 gives the compose form the full width
     and lets the toolbar wrap onto a second line instead of hiding buttons.

Attachment size is also not a skin matter. It is governed by PHP's
upload_max_filesize and post_max_size, and by Roundcube's max_message_size.

WHAT IT DOES NOT DO
-------------------
Nothing outside the skins folder. It does not touch mail delivery, Postfix,
Dovecot, rspamd, any database, or any other site on the server.

WHAT IS STILL NOT GMAIL — stated plainly
----------------------------------------
- CORRECTION TO AN EARLIER NOTE: Roundcube DOES support threading. It has
  IMAP THREAD=REFS in core and a Threads button in the mail toolbar, and it
  groups a conversation into an expandable tree. What it does not do is merge
  a conversation into a single Gmail-style card. An earlier version of this
  file said Roundcube had no threading at all. That was wrong.
- No preview snippet in the list. Gmail shows "Subject - first line of the
  message"; Roundcube does not fetch message bodies when it builds the list,
  so no skin can add that. It needs a plugin or a core change.
- No category tabs (Primary / Promotions / Social). Those are a Gmail SERVER
  feature, not a mail-client one. Nothing self-hosted can reproduce them
  without building the classifier.
- The compose window is a full page, not a floating panel in the corner.
  Moving it would mean forking a template, which this skin will not do.
- The reading pane is always on screen rather than appearing only when you
  open a message. Hiding it was tried and withdrawn: it could not be proven
  safe in testing, and a skin that might stop you opening mail is not worth
  a nicer empty state.
- Roundcube's layout setting (widescreen / desktop / list) does NOT change
  the pane widths — all three give 248 / 372 / 742. The setting is restored
  because the choice is worth having, but it is not what makes this look
  different. The CSS is.

INSTALLING
----------
Unzip so the folder lands at:

  /www/wwwroot/mail.chandrahastech.org/skins/ritzscha/

Then Settings > Preferences > User Interface > Interface skin > RitzSCHA Mail.

THEN, for the logos, add this block to the END of config/config.inc.php,
above the closing tag if there is one. Take a copy of that file first, and
note the file is owned by www:www — the edit needs sudo.

$config['skin_logo'] = [
    'ritzscha:login'         => 'skins/ritzscha/images/logo.png',
    'ritzscha:login[dark]'   => 'skins/ritzscha/images/logo-dark.png',
    'ritzscha:*'             => 'skins/ritzscha/images/logo-mark.png',
    'ritzscha:*[dark]'       => 'skins/ritzscha/images/logo-mark-dark.png',
    'ritzscha:*[small]'      => 'skins/ritzscha/images/logo-mark.png',
    'ritzscha:*[small-dark]' => 'skins/ritzscha/images/logo-mark-dark.png',
];

Without that block the skin still works — it simply shows Roundcube's own
logo. Nothing breaks.

ROLLBACK
--------
Set the skin back to Elastic. Remove the skin_logo block from config if it
was added. If the interface is ever unusable, delete the
folder skins/ritzscha and Roundcube falls back to Elastic on the next refresh.

REBUILDING AFTER A ROUNDCUBE UPGRADE
------------------------------------
The CSS is compiled, not live-inherited. After any Roundcube upgrade the skin
must be recompiled against the new Elastic sources and re-tested. It will not
break on its own, but it will slowly drift out of step with the parent.
